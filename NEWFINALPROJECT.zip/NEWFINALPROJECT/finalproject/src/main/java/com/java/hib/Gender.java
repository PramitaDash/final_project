package com.java.hib;

public enum Gender {
	MALE, FEMALE;

	boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}
}
